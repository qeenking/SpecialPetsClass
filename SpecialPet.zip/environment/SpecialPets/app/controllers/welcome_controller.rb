class WelcomeController < ApplicationController
  def index
    @time = Time.now
  end
  
  def Fox
    @time = Time.now
  end
  
  def Hedgehog
    @time = Time.now
  end
  
  def Meerkat
    @time = Time.now
  end
  
  def Parrot
    @time = Time.now
  end
  
  def Racoon
    @time = Time.now
  end
  
  
end
